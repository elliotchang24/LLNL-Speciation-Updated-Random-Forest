###############################################################################################

README.txt File in Running LLNL Speciation Updated Random Forest (L-SURF) algorithm

###############################################################################################

To execute the LSURF_v1 Jupyter notebook:

1) Download 3 items:
   a) phreeqc folder
   b) LSURF_v1 notebook
   c) sc.subset csv file

2) Drag phreeqc folder onto Desktop to ensure Permissions are enabled for this file access.
We will be calling on this folder, which contains the phreeqc executable and stores L-SURF outputs.\

3) Ensure LSURF_v1 notebook and sc.subset are in the same folder.

4) Open LSURF_v1 notebook and modify paths as defined in the "Preparing Paths" section of the code.
Notably, modify the 'phreeqc_dir' -- this is where your phreeqc file is located (on the Desktop).

5) Ensure sklearn version has been updated to the latest, current version.

6) Click 'Run All Cells'.


Troubleshooting, feedback, and questions may be directed to Dr. Elliot Chang (chang58@llnl.gov).